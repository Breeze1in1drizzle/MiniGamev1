let SceneMenuData = {
    //用于存储球球的速度
    v: null,
    //打开标志
    openTag: false
}

module.exports = SceneMenuData;