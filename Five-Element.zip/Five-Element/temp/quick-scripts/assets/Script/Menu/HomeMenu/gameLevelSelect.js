(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Menu/HomeMenu/gameLevelSelect.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'e8876LEVpBO/qdIqscTkkpd', 'gameLevelSelect', __filename);
// Script/Menu/HomeMenu/gameLevelSelect.js

'use strict';

var currentData = require('../../GlobalData/CurrentData');
var globalMusicSource = require('../../GlobalData/GlobalMusicSource');
cc.Class({
    extends: cc.Component,

    properties: {
        level1: cc.Component,
        level2: cc.Component,
        level3: cc.Component,
        level4: cc.Component,
        //mainPage
        mainPage: cc.Component,
        //gameInstruction
        gameLevelSelect: cc.Component
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.levelArray = new Array(this.level1, this.level2, this.level3, this.level4);
        //设置level，如果通关了就不显示
        /**currentData.goThroughlevelMark[currentData.currentRoundNum - 1] */
        for (var i = 0; i < currentData.roundSum; i++) {
            if (currentData.goThroughLockMark[i]) {
                this.levelArray[i].node.getChildByName('lock').active = false;
            } else {
                this.levelArray[i].node.getChildByName('button').getComponent(cc.Button).interactable = false;
            }
        }
    },
    start: function start() {},
    onClickBotton: function onClickBotton(obj, data) {
        //按钮点击音效button
        cc.audioEngine.play(globalMusicSource.button, false, globalMusicSource.acoustics);
        if (data == 'return') {
            this.mainPage.node.active = true;
            this.gameLevelSelect.node.active = false;
        } else {
            //设置刚开始的关卡
            currentData.currentRoundNum = parseInt(data);
            cc.director.loadScene("round");
        }
    }
    // update (dt) {},

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=gameLevelSelect.js.map
        