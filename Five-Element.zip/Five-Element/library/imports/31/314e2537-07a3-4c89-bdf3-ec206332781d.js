"use strict";
cc._RF.push(module, '314e2U3B6NMib3z7CBjMngd', 'SceneMenuData');
// Script/Menu/SceneMenu/SceneMenuData.js

"use strict";

var SceneMenuData = {
    //用于存储球球的速度
    v: null,
    //打开标志
    openTag: false
};

module.exports = SceneMenuData;

cc._RF.pop();