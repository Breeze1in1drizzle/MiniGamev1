(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Menu/SceneMenu/SceneMenuBotton.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, 'f651euTpq9JVY2UVCI0XHRz', 'SceneMenuBotton', __filename);
// Script/Menu/SceneMenu/SceneMenuBotton.js

'use strict';

var SceneMenuData = require('SceneMenuData');
var CurrentData = require('../../GlobalData/CurrentData');
var globalMusicSource = require('../../GlobalData/GlobalMusicSource');
cc.Class({
    extends: cc.Component,
    properties: {
        mapInitializer: cc.Component
    },
    // LIFE-CYCLE CALLBACKS:
    onLoad: function onLoad() {
        this.openTag = true;
    },
    start: function start() {},

    //点击了按钮
    onClickBotton: function onClickBotton(obj, data) {
        //按钮点击音效button
        cc.audioEngine.play(globalMusicSource.button, false, globalMusicSource.acoustics);
        //回到游戏
        if (data == 'buttonPlay') {
            var ballNode = this.mapInitializer.node.getChildByName('ball');
            //设回球球能被控制
            ballNode.getComponent('InputListener').canController = true;
            ballNode.getComponent('G-SensorListener').canController = true;
            //设回能旋转
            ballNode.getComponent(cc.RigidBody).fixedRotation = false;
            //速度回去
            ballNode.getComponent(cc.RigidBody).linearVelocity = SceneMenuData.v;
            //如果球球曾设为吸收非吸收状态，设回去
            if (this.haveSetUnabsorted == true) {
                ballNode.getComponent('Ball').beAbsorted = true;
                this.haveSetUnabsorted = false;
            }
            //关闭掩膜
            this.node.getParent().getChildByName('maskFilm').active = false;
            //设置打开标志
            SceneMenuData.openTag = false;
            //按钮撤回
            this.node.active = false;
        }
        //回到主菜单
        else if (data == 'buttonHome') {
                //关卡数设置0
                CurrentData.currentRoundNum = 0;
                //设置会scene菜单打开标志
                SceneMenuData.openTag = false;
                //回到主菜单
                cc.director.loadScene("homeMenu");
            }
            //重新开始游戏
            else if (data == 'buttonReplay') {
                    //设置会scene菜单打开标志
                    SceneMenuData.openTag = false;
                    //重新加载当前场景
                    cc.director.loadScene("round");
                }
                //打开tip
                else if (data == 'buttonTips') {
                        //scene上的按钮停止使用，防止用户不小心触摸
                        this.node.getChildByName('buttonReplay').active = false;
                        this.node.getChildByName('buttonPlay').active = false;
                        this.node.getChildByName('buttonHome').active = false;
                        this.node.getParent().getChildByName('tip').active = true;
                    }
    }
    // update (dt) {},

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=SceneMenuBotton.js.map
        