(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Menu/SceneMenu/TipMenu.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '446c1iNdsxKu6kCiRnJL8qh', 'TipMenu', __filename);
// Script/Menu/SceneMenu/TipMenu.js

'use strict';

var globalMusicSource = require('../../GlobalData/GlobalMusicSource');
cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},
    onClickButton: function onClickButton(obj, data) {
        if (data == 'return') {
            //按钮点击音效button
            cc.audioEngine.play(globalMusicSource.button, false, globalMusicSource.acoustics);
            //scene上的按钮重新生效
            this.node.getParent().getChildByName('sceneMenuBotton').getChildByName('buttonReplay').active = true;
            this.node.getParent().getChildByName('sceneMenuBotton').getChildByName('buttonPlay').active = true;
            this.node.getParent().getChildByName('sceneMenuBotton').getChildByName('buttonHome').active = true;
            //tip节点消失
            this.node.active = false;
        }
    }
    // update (dt) {},

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=TipMenu.js.map
        