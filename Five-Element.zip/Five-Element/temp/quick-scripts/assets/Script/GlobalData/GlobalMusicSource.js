(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/GlobalData/GlobalMusicSource.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '7025fbdZrJMkaBwxMRaKjdV', 'GlobalMusicSource', __filename);
// Script/GlobalData/GlobalMusicSource.js

"use strict";

var globalMusicSource = {
    //最大音量大小
    maximumVolume: 5,
    //背景音乐大小
    bgmVolume: 0,
    //音效大小
    acoustics: 0,
    //音效资源
    button: {
        type: cc.AudioClip,
        default: null
    },
    ding: {
        type: cc.AudioClip,
        default: null
    },
    failure: {
        type: cc.AudioClip,
        default: null
    },
    success: {
        type: cc.AudioClip,
        default: null
    },
    swoosh: {
        type: cc.AudioClip,
        default: null
    },
    mentionsound: {
        type: cc.AudioClip,
        default: null
    },
    //bgm对象
    bgm: null
};

module.exports = globalMusicSource;

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=GlobalMusicSource.js.map
        