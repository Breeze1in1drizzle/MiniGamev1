"use strict";
cc._RF.push(module, '3fae6voe+VI7rJa1oUbpllU', 'homeMenu');
// Script/Menu/HomeMenu/homeMenu.js

'use strict';

var globalMusicSource = require('../../GlobalData/GlobalMusicSource');
cc.Class({
    extends: cc.Component,
    properties: {
        //左箭头
        leftChevron: cc.Component,
        leftChevronMoveTag: -1,
        //右箭头
        rightChevron: cc.Component,
        rightChevronMoveTag: -1,
        //内外圈变量
        outerCircle: cc.Component,
        innerCircle: cc.Component
    },
    onLoad: function onLoad() {
        //子节点数组
        this.optionArray = new Array(this.node.getChildByName('instruction(wood)'), this.node.getChildByName('acoustics(water)'), this.node.getChildByName('startGame(fire)'), this.node.getChildByName('stageSelect(soil)'), this.node.getChildByName('exit(metal)'));
        //监听触摸开始
        this.node.on(cc.Node.EventType.TOUCH_START, this.on_touch_start, this);
        //监听触摸移动
        this.node.on(cc.Node.EventType.TOUCH_MOVE, this.on_touch_move, this);
        //监听触摸在区域内离开
        this.node.on(cc.Node.EventType.TOUCH_END, this.on_touch_end, this);
        //监听触摸在区域外离开
        this.node.on(cc.Node.EventType.TOUCH_CANCEL, this.on_touch_end, this);
        //设置界面选项的显示
        this.setOptionShow();
    },

    //触摸监听开始回调函数
    on_touch_start: function on_touch_start(t) {},

    //触摸监听移动回调函数
    on_touch_move: function on_touch_move(event) {},

    //触摸监听离开回调函数
    on_touch_end: function on_touch_end(event) {
        var startPoint = event.currentTouch._startPoint;
        var prevPoint = event.currentTouch._prevPoint;
        var difference = prevPoint.x - startPoint.x;
        //重新排序选项数组
        if (prevPoint.x - startPoint.x > 0) {
            this.resort(1);
            //按钮切换音效
            cc.audioEngine.play(globalMusicSource.swoosh, false, globalMusicSource.acoustics);
            this.setOptionShow();
        } else if (prevPoint.x - startPoint.x < 0) {
            //按钮切换音效
            cc.audioEngine.play(globalMusicSource.swoosh, false, globalMusicSource.acoustics);
            this.resort(-1);
            this.setOptionShow();
        }
    },

    //用于重新排序选项数组
    resort: function resort(flag) {
        var optionArray = this.optionArray;
        //为正，数组右移
        if (flag == 1) {
            var temp = optionArray[0];
            for (var i = 0; i < 5; i++) {
                //调整次数
                var t = optionArray[(i + 1) % 5];
                optionArray[(i + 1) % 5] = temp;
                temp = t;
            }
        }
        //为负，数组左移
        else if (flag == -1) {
                var _temp = optionArray[4];
                for (var _i = 4; _i >= 0; _i--) {
                    //调整次数
                    var index = _i - 1;
                    if (index == -1) index = 4;
                    var _t = optionArray[index];
                    optionArray[index] = _temp;
                    _temp = _t;
                }
            }
    },

    //用于设置界面选项的显示
    setOptionShow: function setOptionShow() {
        //内外圈转动
        this.outerCircle.node.angle = (this.outerCircle.node.angle + 75) % 350;
        this.innerCircle.node.angle = (this.innerCircle.node.angle - 75) % -350;

        var optionArray = this.optionArray;
        //从左数起设置,从零开始
        var option0 = optionArray[0];
        option0.setPosition(cc.v2(-470, -110));
        option0.getChildByName('sprayPaint').active = false;
        option0.getChildByName('label').active = false;
        option0.getChildByName('button').active = false;

        var option1 = optionArray[1];
        option1.setPosition(cc.v2(-310, -110));
        option1.getChildByName('sprayPaint').active = false;
        option1.getChildByName('label').active = false;
        option1.getChildByName('button').active = false;

        var option2 = optionArray[2];
        option2.setPosition(cc.v2(0, 0));
        option2.getChildByName('sprayPaint').active = true;
        option2.getChildByName('label').active = true;
        option2.getChildByName('button').active = false;
        option2.getChildByName('button').active = true;

        var option3 = optionArray[3];
        option3.setPosition(cc.v2(310, -110));
        option3.getChildByName('sprayPaint').active = false;
        option3.getChildByName('label').active = false;
        option3.getChildByName('button').active = false;

        var option4 = optionArray[4];
        option4.setPosition(cc.v2(470, -110));
        option4.getChildByName('sprayPaint').active = false;
        option4.getChildByName('label').active = false;
        option4.getChildByName('button').active = false;

        var acousticsNode = this.node.getChildByName('acoustics(water)');
        if (option2.name == 'acoustics(water)') {
            acousticsNode.getChildByName('word').active = true;
            acousticsNode.getChildByName('label').active = false;
        } else {
            acousticsNode.getChildByName('word').active = false;
            acousticsNode.getChildByName('label').active = false;
        }
    },
    start: function start() {},
    onClickBotton: function onClickBotton(obj, data) {
        //按钮点击音效button
        cc.audioEngine.play(globalMusicSource.swoosh, false, globalMusicSource.acoustics);
        //定义
        var optionArray = this.optionArray;
        //如果是开始游戏startGame
        if (data == 'leftChevron') {
            var temp = optionArray[0];
            for (var i = 0; i < 5; i++) {
                //调整次数
                var t = optionArray[(i + 1) % 5];
                optionArray[(i + 1) % 5] = temp;
                temp = t;
            }
        } else if (data == 'rightChevron') {
            var _temp2 = optionArray[4];
            for (var _i2 = 4; _i2 >= 0; _i2--) {
                //调整次数
                var index = _i2 - 1;
                if (index == -1) index = 4;
                var _t2 = optionArray[index];
                optionArray[index] = _temp2;
                _temp2 = _t2;
            }
        }
        this.setOptionShow();
    },
    update: function update(dt) {
        /*左箭头
        leftChevron: cc.Component,
            //右箭头
            rightChevron: cc.Component */
        //左箭头运行
        var lx = this.leftChevron.node.getPosition().x;
        var ly = this.leftChevron.node.getPosition().y;
        if (this.leftChevronMoveTag == -1) {
            //-1为向左
            if (lx > -230) {
                this.leftChevron.node.setPosition(cc.v2(lx - 1, ly));
            } else this.leftChevronMoveTag = 1;
        } else {
            if (lx < -210) {
                this.leftChevron.node.setPosition(cc.v2(lx + 1, ly));
            } else this.leftChevronMoveTag = -1;
        }
        //右箭头运行
        var rx = this.rightChevron.node.getPosition().x;
        var ry = this.rightChevron.node.getPosition().y;
        if (this.rightChevronMoveTag == -1) {
            //-1为向左
            if (rx < 230) {
                this.rightChevron.node.setPosition(cc.v2(rx + 1, ly));
            } else this.rightChevronMoveTag = 1;
        } else {
            if (rx > 210) {
                this.rightChevron.node.setPosition(cc.v2(rx - 1, ly));
            } else this.rightChevronMoveTag = -1;
        }
    }
});

cc._RF.pop();