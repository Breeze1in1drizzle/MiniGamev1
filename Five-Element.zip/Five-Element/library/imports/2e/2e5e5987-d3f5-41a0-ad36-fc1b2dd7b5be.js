"use strict";
cc._RF.push(module, '2e5e5mH0/VBoK02/Bst17W+', 'Camera');
// Script/Physics/Camera.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        resultMenu: cc.Component,
        sceneMenu: cc.Component,
        position: cc.v2
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.position = this.node.getPosition();
    },
    start: function start() {},
    update: function update(dt) {
        if (this.position != this.node.getPosition()) {
            this.position = this.node.getPosition();
            this.resultMenu.node.setPosition(this.position);
            this.sceneMenu.node.setPosition(this.position);
        }
    }
});

cc._RF.pop();