(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Physics/PhysicsManager.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '565abORnGJBMoKrTSRzDgmM', 'PhysicsManager', __filename);
// Script/PhysicsManager.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        is_dubug: false,
        gravity: cc.v2(0, -320)
    },

    onLoad: function onLoad() {
        //启动物理管理器，即开启物理碰撞效果
        cc.director.getPhysicsManager().enabled = true;
        //开启调试模式
        if (this.is_dubug) {
            var Bits = cc.PhysicsManager.DrawBits; //显示的类型
            cc.director.getPhysicsManager().debugDrawFlags = Bits.e_jointBit | Bits.e_shapeBit;
        } else {
            cc.director.getPhysicsManager().debugDrawFlags = 0;
        }
        //重力加速度的配置
        cc.director.getPhysicsManager().gravity = this.gravity;
    },
    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=PhysicsManager.js.map
        