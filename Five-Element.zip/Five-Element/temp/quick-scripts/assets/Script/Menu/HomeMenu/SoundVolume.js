(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Menu/HomeMenu/SoundVolume.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2a3c34LxylLSLwFZohmWTUP', 'SoundVolume', __filename);
// Script/Menu/HomeMenu/SoundVolume.js

'use strict';

var globalMusicSource = require('../../GlobalData/GlobalMusicSource');
cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {},

    //Handle移动
    onHandleMove: function onHandleMove(obj, data) {
        if (data == 'BGM') {
            //设置背景音乐音量大小
            globalMusicSource.bgmVolume = globalMusicSource.maximumVolume * obj.progress;
            cc.audioEngine.setVolume(globalMusicSource.bgm, globalMusicSource.bgmVolume);
        } else if (data == 'soundEffect') {
            //设置音效音量大小
            globalMusicSource.acoustics = globalMusicSource.maximumVolume * obj.progress;
        }
    }
    // update (dt) {},

});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=SoundVolume.js.map
        