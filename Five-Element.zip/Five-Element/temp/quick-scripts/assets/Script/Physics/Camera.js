(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Physics/Camera.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '2e5e5mH0/VBoK02/Bst17W+', 'Camera', __filename);
// Script/Physics/Camera.js

"use strict";

cc.Class({
    extends: cc.Component,

    properties: {
        resultMenu: cc.Component,
        sceneMenu: cc.Component,
        position: cc.v2
    },

    // LIFE-CYCLE CALLBACKS:

    onLoad: function onLoad() {
        this.position = this.node.getPosition();
    },
    start: function start() {},
    update: function update(dt) {
        if (this.position != this.node.getPosition()) {
            this.position = this.node.getPosition();
            this.resultMenu.node.setPosition(this.position);
            this.sceneMenu.node.setPosition(this.position);
        }
    }
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=Camera.js.map
        