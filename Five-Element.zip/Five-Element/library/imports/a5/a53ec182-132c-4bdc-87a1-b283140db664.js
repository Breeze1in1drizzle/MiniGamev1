"use strict";
cc._RF.push(module, 'a53ecGCEyxL3IehsoMUDbZk', 'Key');
// Script/Physics/Key.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        //钥匙运动变量
        keymoving: 0,
        //钥匙x轴
        x: null,
        //钥匙y轴
        y: null
    },

    onLoad: function onLoad() {
        this.x = this.node.getPosition().x;
        this.y = this.node.getPosition().y;
    },
    start: function start() {},
    update: function update(dt) {
        var a = void 0;
        if (this.keymoving % 4 == 0) {
            if (0 <= this.keymoving && this.keymoving <= 39) {
                this.node.setPosition(this.x, this.y++);
                this.keymoving++;
            } else if (40 <= this.keymoving && this.keymoving <= 79) {
                this.node.setPosition(this.x, this.y--);
                this.keymoving++;
            } else this.keymoving = 0;
        } else this.keymoving++;
    }
});

cc._RF.pop();