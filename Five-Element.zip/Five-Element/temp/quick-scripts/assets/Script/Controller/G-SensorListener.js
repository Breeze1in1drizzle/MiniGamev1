(function() {"use strict";var __module = CC_EDITOR ? module : {exports:{}};var __filename = 'preview-scripts/assets/Script/Controller/G-SensorListener.js';var __require = CC_EDITOR ? function (request) {return cc.require(request, require);} : function (request) {return cc.require(request, __filename);};function __define (exports, require, module) {"use strict";
cc._RF.push(module, '46d01uthWdISZ6It3YymvNA', 'G-SensorListener', __filename);
// Script/Controller/G-SensorListener.js

"use strict";

cc.Class({
    extends: cc.Component,
    properties: {
        rigidBody: null, //
        is_move_hori: null, //
        is_move_verti: null, //
        acceleration: 10,
        speedLimit: 800,
        canController: true
    },
    // LIFE-CYCLE CALLBACKS:
    // onLoad () {},
    start: function start() {
        this.rigidBody = this.node.getComponent(cc.RigidBody);
        //重力测试
        cc.systemEvent.setAccelerometerEnabled(true);
        cc.systemEvent.on(cc.SystemEvent.EventType.DEVICEMOTION, this.onDeviceMotionEvent, this);
    },

    onDeviceMotionEvent: function onDeviceMotionEvent(event) {
        if (this.getComponent(cc.RigidBody) == null) return;
        //不能被控制中
        if (!this.canController) return;
        var rigidBody = this.rigidBody;
        var nowGX = event.acc.x.toFixed(2);
        var nowGY = event.acc.y.toFixed(2);
        var nowGZ = event.acc.z.toFixed(2);
        //移动
        var acceleration = this.acceleration;
        var v = rigidBody.linearVelocity;
        var increaseX = v.x + acceleration * nowGX * 100;
        var increaseY = v.y + acceleration * nowGY * 100;
        /*v.x = increaseX
        v.y = increaseY*/
        if (-this.speedLimit < increaseX && increaseX < this.speedLimit) {
            v.x = increaseX;
        }
        if (-this.speedLimit < increaseY && increaseY < this.speedLimit) {
            v.y = increaseY;
        }
        rigidBody.linearVelocity = v;
    }
    // update (dt) {},
});

cc._RF.pop();
        }
        if (CC_EDITOR) {
            __define(__module.exports, __require, __module);
        }
        else {
            cc.registerModuleFunc(__filename, function () {
                __define(__module.exports, __require, __module);
            });
        }
        })();
        //# sourceMappingURL=G-SensorListener.js.map
        