"use strict";
cc._RF.push(module, 'ed2f35JaiRHsI8bKvYF4+ZQ', 'WinListener');
// Script/Physics/WinListener.js

'use strict';

var currentData = require('../GlobalData/CurrentData');

cc.Class({
    extends: cc.Component,

    properties: {},

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start: function start() {}
}

// update (dt) {},
);

cc._RF.pop();